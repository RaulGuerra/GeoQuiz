package com.bignerdranch.android.geoquiz

import android.util.Log
import androidx.lifecycle.ViewModel

private const val TAG = "QuizViewModel"
class QuizViewModel : ViewModel() {
    var currentIndex = 0
    var isCheater = false

    private val questionBank = listOf(
        Question(R.string.question_australia, true),
        Question(R.string.question_oceans, true),
        Question(R.string.question_mideast, false),
        Question(R.string.question_africa, false),
        Question(R.string.question_americas, true),
        Question(R.string.question_asia, true),
        Question(R.string.question_tuvalu, false),
        Question(R.string.question_norway, false),
        Question(R.string.question_tributaries, false),
        Question(R.string.question_england, false),
        Question(R.string.question_iceland, false),
        Question(R.string.question_london,true),
        Question(R.string.question_italy,false),
        Question(R.string.question_malaysia, false),
        Question(R.string.question_milan, true),
        Question(R.string.question_kabul, true)
    )
    
    val currentQuestionAnswer: Boolean
        get() = questionBank[currentIndex].answer
    val currentQuestionText: Int
        get() = questionBank[currentIndex].textResId
    fun moveToNext() {
        currentIndex = (currentIndex + 1) % questionBank.size
    }

    fun moveToPrevious() {
        currentIndex = (currentIndex - 1) % questionBank.size
        if (currentIndex < 0)
            currentIndex = questionBank.size - 1
    }

}